import os


def test_path():
    return os.path.dirname(os.path.realpath(__file__))
